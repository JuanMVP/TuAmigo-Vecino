export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCuGEL7PhsFbUa1nXQWSP94h3F2Y_vItj4",
    authDomain: "bibliotecacof-triana.firebaseapp.com",
    databaseURL: "https://bibliotecacof-triana.firebaseio.com",
    projectId: "bibliotecacof-triana",
    storageBucket: "bibliotecacof-triana.appspot.com",
    messagingSenderId: "321019297538"
  }
};