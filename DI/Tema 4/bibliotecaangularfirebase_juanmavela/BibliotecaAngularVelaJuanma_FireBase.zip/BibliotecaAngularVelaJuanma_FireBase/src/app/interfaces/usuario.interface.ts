export interface UsuarioInterface{
    id:number;
    name:string;
    email:string;
    password:string;
    phone:string;
    notes:string;
}
