export interface SigninResponse {
    token: string;
    email: string;
    name:string;
    role:string;
    password:string;
    
}
