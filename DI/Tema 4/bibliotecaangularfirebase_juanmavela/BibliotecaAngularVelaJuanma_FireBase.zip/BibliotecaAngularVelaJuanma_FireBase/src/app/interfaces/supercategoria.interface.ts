import { Categoria } from "./categoria.interface";

export interface Supercategoria {
    id:number;
    name:string;
    
}
