export interface Tipo{
    id:number;
    name:string;
}