export interface Categoria{
    id:number;
    name:string;
}