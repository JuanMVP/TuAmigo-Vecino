export class PrestarDto{
    userId:number;
 
 
 constructor(uid:number){
     this.userId=uid;
 }
 }
 