export class CategoriaDto{
   name:string;


constructor(n:string){
    this.name=n;
}
}

