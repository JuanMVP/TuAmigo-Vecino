export class SuperCategoryDto{
    name:string;

constructor(n:string){
    this.name=n;
}
}