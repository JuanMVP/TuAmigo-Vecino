export const environment = {
  production: true,
  apiUrl: 'http://www.miguelcamposrivera.com:3003/apibibliotecav2'
};