import { Component, OnInit } from '@angular/core';
import { CrearRecursoService } from 'src/app/services/crear-recurso.service';
import { MatDialogRef } from '@angular/material';
import { CrearRecursoDto } from 'src/app/dto/crear-recurso.dto';
import { Categoria } from 'src/app/interfaces/categoria.interface';
import { Tipo } from 'src/app/interfaces/tipo.interface';
import { CategoriaService } from 'src/app/services/categoria.service';
import { TipoService } from 'src/app/services/tipo.service';

@Component({
  selector: 'app-dialog-add-recurso',
  templateUrl: './dialog-add-recurso.component.html',
  styleUrls: ['./dialog-add-recurso.component.css']
})
export class DialogAddRecursoComponent implements OnInit {
  
  title:string;
  autor:string;
  anyo:number;
  content:string;
  //categoryId:number;
  arrayCategorias:Categoria[];
  typeId:number;
  categoryId:number;
  arrayTipo:Tipo[];
  categoriaSeleccionada: number;
  tipoSeleccionado:number;

  constructor(private crearRecursoService: CrearRecursoService,private tipoService:TipoService, private categoriaService: CategoriaService, public dialogRef: MatDialogRef<DialogAddRecursoComponent> ) { }

  ngOnInit() {
    this.getCategorias();
    this.getTipos();

  }


  addRecurso(){
    
      const crearRecursoDto = new CrearRecursoDto(this.title,this.autor,this.anyo,this.content,this.categoriaSeleccionada,this.tipoSeleccionado);
      this.crearRecursoService.recursoCreate(crearRecursoDto).subscribe(crearRecursoResp =>{
        this.dialogRef.close(crearRecursoResp);
      
      });
      
    }


    getCategorias() {
    
      this.categoriaService.getAllCategorias().subscribe(listaCategorias => {
        this.arrayCategorias = listaCategorias;
   
      }, error => {
        console.log('Error');
      });
    }


    getTipos() {   
      this.tipoService.getAllTipos().subscribe(listaTipos => {
        this.arrayTipo = listaTipos;
   
      }, error => {
        console.log('Error');
      });
    }

}


