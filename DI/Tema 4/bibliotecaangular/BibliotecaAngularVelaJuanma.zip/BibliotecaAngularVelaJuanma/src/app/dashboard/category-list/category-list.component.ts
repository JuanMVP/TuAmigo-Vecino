import { Component, OnInit } from '@angular/core';
import { Categoria } from 'src/app/interfaces/categoria.interface';
import { CategoriaService } from 'src/app/services/categoria.service';
import { MatSnackBar, MatDialog } from '@angular/material';
import { DialogAddCategoryComponent } from '../dialog-add-category/dialog-add-category.component';
import { DialogDeleteCategoryComponent } from '../dialog-delete-category/dialog-delete-category.component';

@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.scss']
})
export class CategoryListComponent implements OnInit {
  displayedColumns: string[] = ['id', 'name','acciones']
  dataSource: Categoria[]
  constructor(private categoriaService: CategoriaService, public snackBar: MatSnackBar, public dialog: MatDialog) { }


  ngOnInit() {
      this.getListaCategorias('Lista de categorías cargada');
      this.showCategory();
  }


  getListaCategorias(mensaje:string){
this.categoriaService.getAllCategorias().subscribe(listaCategorias=>{
  this.dataSource = listaCategorias;

  this.snackBar.open(mensaje,'X',{
    duration:3000,
    verticalPosition:'top'

  });
},error =>{
  this.snackBar.open('Error al obtener categorias', 'X',{
    duration:1000
  });
});
}
getCategorias() {
    
  this.categoriaService.getAllCategorias().subscribe(listaCategorias => {
    this.dataSource = listaCategorias;

  }, error => {
    console.log('Error');
  });
}

showCategory(){
  this.categoriaService.getAllCategorias().subscribe(categoryList =>{
    this.dataSource = categoryList;
  }, error =>{
    console.log('Error, no ha recibido categorias');
  })
}

openDialogCrearCategoria(){
  const dialogNuevaCategoria = this.dialog.open(DialogAddCategoryComponent);
  
  dialogNuevaCategoria.afterClosed().subscribe(resultado =>{
    this.showCategory();
  })
}
openDialogDeleteCategorias(categoria: Categoria) {
  const dialogDeleteCategoria = this.dialog.open(DialogDeleteCategoryComponent, {
    data: {
      element: categoria
    }
  });

  dialogDeleteCategoria.afterClosed().subscribe(response => {
    this.getCategorias();
  }, error => {
    console.log(error);
  });
}
}
