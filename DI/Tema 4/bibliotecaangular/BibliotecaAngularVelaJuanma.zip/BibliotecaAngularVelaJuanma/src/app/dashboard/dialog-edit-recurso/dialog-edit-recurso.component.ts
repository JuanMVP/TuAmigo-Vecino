import { Component, OnInit,Inject  } from '@angular/core';
import { RecursoInterface } from 'src/app/interfaces/recurso.interface';
import { RecursoService } from 'src/app/services/recurso.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog-edit-recurso',
  templateUrl: './dialog-edit-recurso.component.html',
  styleUrls: ['./dialog-edit-recurso.component.scss']
})
export class DialogEditRecursoComponent implements OnInit {

  recurso: RecursoInterface;
  

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private recursoService: RecursoService,
  public dialogRef: MatDialogRef<DialogEditRecursoComponent>) { }

  ngOnInit() {
    
    this.recurso = this.data.recurso;
    
  }
  saveRecurso() {
    this.recursoService.updateRecurso(this.recurso).subscribe(recurso => {
      this.dialogRef.close();
    });
  }

}
