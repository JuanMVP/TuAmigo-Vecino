package com.example.juanmavela.listacolegios_juanma.model;

public interface ColegioInteracionListener {

    public void onColegioMapClick(String latitud,String logintud);
}
