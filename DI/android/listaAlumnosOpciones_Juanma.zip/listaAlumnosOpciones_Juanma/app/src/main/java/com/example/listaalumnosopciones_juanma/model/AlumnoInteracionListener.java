package com.example.listaalumnosopciones_juanma.model;

public interface AlumnoInteracionListener {
}
