# examen-rest-spring

Código fuente necesario para realizar el examen sobre APIs REST con Spring.

2º de Desarrollo de Aplicaciones Multiplataforma
Salesianos Triana (https://triana.salesianos.edu)
