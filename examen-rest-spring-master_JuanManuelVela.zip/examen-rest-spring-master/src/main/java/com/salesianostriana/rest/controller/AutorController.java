package com.salesianostriana.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.salesianostriana.rest.model.Autor;
import com.salesianostriana.rest.security.service.AutorService;

@RestController
public class AutorController {

	@Autowired
	AutorService service;
	
	@GetMapping("/autor")
	public ResponseEntity<?> listaAutores() {
		final List<Autor>autoresList=	service.findAll();
		//TODO Completa todo lo necesario para devolver una lista con todos los autores y los libros que han escrito
		return ResponseEntity.ok(autoresList);
	}
	
	@PostMapping("/autor")
	public ResponseEntity<?> nuevoAutor(@RequestBody Autor autor) {
		final Autor newAutor = new Autor();
		newAutor.setNombre(newAutor.getNombre());
		newAutor.setFechaNacimiento(newAutor.getFechaNacimiento());
		
		 autor = service.addAutor(newAutor);
		 
		
		//TODO Completa todo lo necesario para dar de alta un nuevo autor (sin libros escritos).
		return ResponseEntity.ok(newAutor);
	}

}
