package com.salesianostriana.rest.security.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.rest.model.Autor;
import com.salesianostriana.rest.repositories.AutorRepo;

@Service
public class AutorService {
	
	@Autowired
	AutorRepo repository;
	
	
	public Autor findOne(long id) {
		return repository.findById(id).orElse(null);
	}
	
	public List<Autor> findAll() {
		return repository.findAll();
	}

	public Autor addAutor(Autor aut) {
		return repository.save(aut);
	}
	
}
